﻿using SEDC.Oop.Class06.Exercise03.ATMModels;
using System;

namespace SEDC.Oop.Class06.Exercise03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Customers[] customersArray = new Customers[3]; 
            bool flag = true;
            while(true)
            {
                Console.WriteLine("Do ypu already have an account? Press 1 for yes and 2 for No(to sign up)");
                string hasAccount = Console.ReadLine();
                if (hasAccount == "1")
                {
                    Console.WriteLine("Welcome to the ATM app!");
                    Console.WriteLine("Enter your username");
                    string username = Console.ReadLine();
                    Console.WriteLine("Please enter your credit card number");
                    string ccNumber = Console.ReadLine();
                    Console.WriteLine("Please enter your PIN number");
                    string pin = Console.ReadLine();
                    bool isOKay = int.TryParse(pin, out int pinNumber);
                    // bool isOKayCCNumber = int.TryParse(ccNumber, out int ccIntNumber);
                    if (isOKay)
                    {
                        Customers customer = new Customers(username, ccNumber, pinNumber);
                        string choice = Customers.Authentication(customersArray, ccIntNumber, pinNumber);

                        switch (choice)
                        {
                            case "a":
                                customer.BalanceChecking(customersArray, ccNumber);
                                break;
                            case "b":
                                customer.CashWithdrawal(customersArray, ccNumber);
                                break;
                            case "c":
                                customer.CashDeposition(customersArray, ccNumber);
                                break;
                            default:
                                customer.BalanceChecking(customersArray, ccNumber);
                                break;

                        }
                        flag = false;
                        break;
                    }

                    Console.WriteLine("Enter a valid pin!");
                    continue;
                }

                else if (hasAccount == "2")
                {
                    Console.WriteLine("Welcome to the ATM app!");
                    Console.WriteLine("Enter your register username");
                    string username = Console.ReadLine();
                    Console.WriteLine("Please enter your credit card number");
                    string ccNumber = Console.ReadLine();
                    Console.WriteLine("Please enter your PIN number");
                    string pin = Console.ReadLine();
                    bool isOKay = int.TryParse(pin, out int pinNumber);
                    // bool isOKayCCNumber = int.TryParse(ccNumber, out int ccIntNumber);
                    if (isOKay)
                    {
                        Customers customer = new Customers(username, ccNumber, pinNumber);
                    }
            }
        }
    }
}
