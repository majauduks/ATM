﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDC.Oop.Class06.Exercise03.ATMModels
{
    public class Customers
    {
        public string Name { get; set; }
        public int CardNumber { get; set; }
        private int Pin { get; set; }

        private int Balance { get; set; }


        public Customers(string username, int cardNumber, int pin)
        {
            Name = username;
            CardNumber = cardNumber;
            Pin = pin;
            Balance = 0;
        }

        public string Authentication(Customers[] allCustomers, string cardNumber, int pin)
        {
            foreach (Customers customer in allCustomers)
            {
                if (CreditCardNumber(allCustomers, customer.CardNumber) == cardNumber && customer.Pin == pin)
                {
                    Console.WriteLine($"Welcome {customer.Name}");
                    Console.WriteLine("What would you want to do? Choose between: a. Check balance \nb. Cash Withrdawal \nc.Cash Deposit");
                    string choice = Console.ReadLine();
                    return choice;
                }
                else
                {
                    Console.WriteLine("You entered invalid information");
                    return "ha";
                }
            }
            return "ha";
        }


        public void BalanceChecking(Customers[] allCustomers, string cardNumber)
        {
            foreach (Customers customer in allCustomers)
            {
                if (customer.CardNumber == cardNumber)
                {
                    Console.WriteLine($"Your current balance is: {customer.Balance}");
                }
            }
        }



        public void CashWithdrawal(Customers[] allCustomers, string cardNumber)
        {
            foreach (Customers customers in allCustomers)
            {
                if (cardNumber == customers.CardNumber)
                {
                    bool flag = true;
                    while (flag)
                    {
                        Console.WriteLine("How much money would you like to withdraw?");
                        string answer = Console.ReadLine();
                        bool isOkay = int.TryParse(answer, out int moneyToWithdraw);
                        if (isOkay)
                        {
                            if (moneyToWithdraw > customers.Balance)
                            {
                                customers.Balance -= moneyToWithdraw;
                                Console.WriteLine($"Money has been withdrawn! You withdrew {moneyToWithdraw} and your current balance is {customers.Balance}");
                                Console.WriteLine("Do you want to make another transation? For yes, press 'y");
                                string anotherTransation = Console.ReadLine();
                                string anotherTransationLC = anotherTransation.ToLower();
                                if (anotherTransationLC == "y")
                                {
                                    continue;
                                }
                                else
                                {
                                    Console.WriteLine("Thank you for using our bank. Have a nice day");
                                    flag = false;

                                }
                            }

                            else
                            {
                                Console.WriteLine("You don't have enough money for this transaction!");
                                Console.WriteLine("Do you want to make another transation? For yes, press 'y");
                                string anotherTransation = Console.ReadLine();
                                string anotherTransationLC = anotherTransation.ToLower();
                                if (anotherTransationLC == "y")
                                {
                                    continue;
                                }
                                else
                                {
                                    Console.WriteLine("Thank you for using our bank. Have a nice day");
                                    flag = false;

                                }

                            }
                        }

                    }


                }


            }

        }

        public int CreditCardNumber(Customers[] customers, string cardNumber)
        {
            bool flag = false;
            while (!flag)
            {
                foreach (Customers customer in customers)
                {
                    string stringReduced = cardNumber.Trim('-');
                    bool isOkay = int.TryParse(stringReduced, out int cardNumberTrimmed);
                    if (isOkay)
                    {
                        if (cardNumberTrimmed == customer.CardNumber)
                        {
                            flag = true;
                            return cardNumberTrimmed;
                        }


                    }
                    else
                    {
                        Console.WriteLine("Enter a valid card number!");
                        continue;
                    }

                }
            }

            return 0;
        }

        public void CashDeposition(Customers[] allCustomers, string cardNumber)
        {
            foreach (Customers customers in allCustomers)
            {
                if (cardNumber == customers.CardNumber)
                {
                    bool flag = true;
                    while (flag)
                    {
                        Console.WriteLine("How much money would you like to withdraw?");
                        string answer = Console.ReadLine();
                        bool isOkay = int.TryParse(answer, out int moneyToDeposit);
                        if (isOkay)
                        {
                            customers.Balance += moneyToDeposit;
                            Console.WriteLine($"Money has been deposited!Your current balance is {customers.Balance}");
                            Console.WriteLine("Do you want to make another transation? For yes, press 'y");
                            string anotherTransation = Console.ReadLine();
                            string anotherTransationLC = anotherTransation.ToLower();
                            if (anotherTransationLC == "y")
                            {
                                continue;
                            }
                            else
                            {
                                Console.WriteLine("Thank you for using our bank. Have a nice day");
                                flag = false;
                            }
                        }
                    }
                }
            }
        }



        public Customers[] NewUSer(Customers[] customers, string username, string password)
        {
            bool flag = true;
            while (flag)
            {
                    Console.WriteLine("Enter the card number you want int the type XXXX-XXXX-XXXX-XXXX");
                    string wish = Console.ReadLine().Trim('-');
                    bool isOkay = int.TryParse(wish, out int cardNumberCustomer);
                if (isOkay) {
                    foreach (Customers customer in customers)
                    {
                        if (customer.CardNumber == cardNumberCustomer)
                        {
                            Console.WriteLine("There is already a customer with this card number. Do you wish to enter a new one? Type 'y' for yes!");
                            string newOne = Console.ReadLine();
                            if (newOne == "y")
                            {
                                continue;
                            }
                            else
                            {
                             
                            return customers;
                            }
                        }

                        else
                        {
                            Console.WriteLine("Enter a username");
                            string usernameNew = Console.ReadLine();
                            Console.WriteLine("Enter a password");
                            string passwordNew = Console.ReadLine();
                            Array.Resize(ref customers, customers.Length+1);
                            customers[customers.Length - 1] = new Customers(username, cardNumberCustomer, passwordNew);
                            return customers;
                        }
                    }
                }

            }
                return customers;
        }
    }
        
}

